Nous allons explorer les origines de REST et l'ensemble des concepts et contraintes qui sont autour.
[[question]]
| Pourquoi utiliser REST plutôt qu'une autre technologie ou architecture ? Quelles avantages cela peut-il nous apporter ?
