
Le protocole HTTP se prête bien au jeu de REST. À l'heure actuelle, la plupart des API RESTful l'utilisent vu que les technologies pour l'exploiter sont très largement répandues.

Ici prend fin l'aparté sur la partie théorique de ce cours. La suite sera grandement axée sur la pratique, tous les concepts seront abordés en se basant sur des exemples concrets.

Nous allons donc voir comment appliquer les concepts et contraintes REST dans une application web. Cela nous offrira une API uniforme avec une prise en main facile. L'objectif est d'avoir à la fin de ce cours une API pleinement fonctionnelle.
