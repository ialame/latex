Dans cette section, nous allons aborder quelques points intéressants qui reviennent souvent dans les questions concernant ce cours.

Les points abordés n'ont pas de relation particulière et peuvent donc être lu dans n'importe quel ordre.