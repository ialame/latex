Revenons un peu sur les relations entre les ressources.

À la création d'un lieu, nous ne pouvons pas renseigner les tarifs. Nous sommes donc obligés de créer d'abord un lieu avant de rajouter ses tarifs.

Même si ce fonctionnement pourrait convenir dans certains cas, il peut aussi s'avérer utile de créer un lieu et de lui associer des tarifs avec un seul appel API. On pourra ainsi optimiser l'API et réduire les interactions entre le client et le serveur.

Nous allons donc voir dans cette partie comment arriver à un tel résultat avec Symfony.
