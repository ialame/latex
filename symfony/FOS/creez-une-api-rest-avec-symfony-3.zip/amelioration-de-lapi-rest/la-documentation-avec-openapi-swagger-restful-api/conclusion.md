Après cette brève initiation à *OpenAPI*, connu aussi sous le nom de *Swagger RESTFul API*, vous avez pu remarquer que l’écosystème autour de cette technologie est assez riche.

Ces spécifications se basent sur un ensemble de standards reconnus comme [JSON Schema](http://json-schema.org/) qui facilitent grandement sa prise en main. 

Le fichier ***swagger.json*** ainsi obtenu peut être exploité par beaucoup d'outils qui permettent d'augmenter notre productivité (Génération de code client, génération de code serveur, interface de documentation avec bac à sable, etc.).