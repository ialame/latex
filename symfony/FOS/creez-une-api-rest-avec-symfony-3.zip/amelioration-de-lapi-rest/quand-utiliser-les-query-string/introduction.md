Jusqu'à présent les query strings ou paramètres d'URL ont été recalés dans tous les choix de conception que nous avons déjà faits.

Ces composants à part entière du protocole HTTP peuvent être exploités dans une API REST pour atteindre différents objectifs.

Dans cette partie, nous allons aborder quelques cas pratiques où les query strings peuvent être utilisés.

Tout au long de cette partie, le terme *query strings* sera utilisé pour désigner les paramètres d'URL.
