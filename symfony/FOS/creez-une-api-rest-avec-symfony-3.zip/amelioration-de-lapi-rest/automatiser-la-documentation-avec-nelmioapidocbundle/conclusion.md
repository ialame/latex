*ApiDocBundle* supporte les différents bundles de Symfony et le tout permet d'avoir un ensemble harmonieux et facilite les développements.

L'un des problèmes les plus communs lorsque nous écrivons une documentation est de la maintenir à jour. Avec une documentation proche du code, il est maintenant très facile de la corriger en même temps que le code évolue.

En effet, un utilisant les annotations de *FOSRestBundle*, les formulaires de Symfony et les fichiers de sérialisation de *JMSSerializerBundle*, nous avons la garantie que la documentation est toujours à jour avec notre code.

Il ne reste plus qu'à tout mettre en production !
