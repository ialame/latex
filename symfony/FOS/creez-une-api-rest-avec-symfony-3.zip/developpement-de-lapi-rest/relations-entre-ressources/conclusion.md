Avec ce chapitre, nous venons de faire un tour complet des concepts de base pour développer une API RESTful. 
Les possibilités d'évolution de notre API sont nombreuses et ne dépendent que de notre imagination.

Maintenant que les sous ressources n'ont plus de secrets pour nous, nous allons implémenter la fonctionnalité de base de notre API : Proposer une idée de sortie à un utilisateur.