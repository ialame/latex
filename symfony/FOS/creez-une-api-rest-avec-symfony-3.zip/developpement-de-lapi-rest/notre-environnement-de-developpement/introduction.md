Afin d'avoir un environnement de développement de référence pendant ce cours, nous allons voir ensemble les technologies qui seront utilisées et surtout à quelles versions. 

Vous pourrez ainsi tester les différents codes qui seront fournis.
Il est utile de rappeler que pour suivre ce cours vous devez avoir un minimum de connaissances en PHP et Symfony. Certains aspects de configuration comme l'installation de MySQL, Apache ou autres ne seront pas abordés.
Si vous n'avez jamais procédé à l'installation de Symfony, il est préférable de se documenter sur le sujet avant de commencer ce cours.