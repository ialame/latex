Maintenant que nous pouvons lire, écrire et supprimer des ressources, il ne reste plus qu'à apprendre à les modifier et le CRUD[^crud] (Créer, Lire, Mettre à jour et Supprimer ) en REST n'aura plus de secret pour nous.

Dans cette partie, nous aborderons les concepts liés à la mise à jour de ressources REST et nous ferons un petit détour sur la gestion des erreurs avec *FOSRestBundle*.

[^crud]: **C**reate **R**ead **U**pdate **D**elete