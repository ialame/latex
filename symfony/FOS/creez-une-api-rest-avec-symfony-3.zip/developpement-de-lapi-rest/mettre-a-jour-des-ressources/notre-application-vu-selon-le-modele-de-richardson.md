Pour rappel, le modèle de Richardson est un modèle qui permet d'évaluer son application selon les principes REST.

![Le niveau de maturité de notre application](http://zestedesavoir.com/media/galleries/3183/3cf6b12a-9169-4215-9465-bcdafb42a5b1.png)

Nous pouvons facilement affirmer que notre application est au niveau 2 vu que nous exploitons les différents verbes que propose le protocole HTTP pour interagir avec des ressources identifiées par des URIs. Nous verrons plus tard comment s'approcher du niveau 3 en exploitant d'autres bundles de Symfony à notre disposition.