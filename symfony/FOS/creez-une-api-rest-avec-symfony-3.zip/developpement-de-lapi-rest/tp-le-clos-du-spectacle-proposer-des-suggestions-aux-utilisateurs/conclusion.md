Les fonctionnalités que nous voulons pour notre application peuvent être implémentées assez facilement sans se soucier des contraintes imposées par le style d'architecture REST.
REST n'intervient que pour définir l'API à utiliser pour accéder à ces fonctionnalités et nous laisse donc la responsabilité des choix techniques et de conceptions.

Vous pouvez vous entrainer et améliorer l'API en rajoutant encore plus de fonctionnalités. Nous pouvons par exemple imaginer que chaque utilisateur à un budget et que les tarifs des lieux sont pris en compte pour améliorer les suggestions. 