[[question]]
|Pourquoi parle-t-on tant des ressources ?

Au-delà de connaitre la définition d'une ressource en REST, un des principaux problèmes lorsque nous développons une API est de savoir quelles sont les entités de notre projet qui sont éligibles.
Dans cette partie du cours, nous allons donc voir comment bien identifier une ressource avec une expression du besoin plus claire et aussi comment les exposer avec une URI (Uniform Resource Identifier).